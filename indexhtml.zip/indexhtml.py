<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Election 2025 Results</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- External stylesheet only  -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header id="top">
        <div class="site-header">
            <h1>Election 2025 Results</h1>
            <p class="tagline">Philadelphia District Attorney &amp; City Controller</p>
        </div>

        <nav aria-label="Main navigation">
            <!-- Internal links (anchor links) for navigation -->
            <ul class="nav-list">
                <li><a href="#overview">Overview</a></li>
                <li><a href="#da-results">District Attorney</a></li>
                <li><a href="#controller-results">City Controller</a></li>
                <li><a href="#sources">Sources</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- SECTION 1: Overview -->
        <section id="overview" class="section">
            <h2>Overview of the 2025 Philadelphia Election</h2>
            <p>
                On November 4, 2025, Philadelphia voters chose the city’s 
                <strong>District Attorney</strong> and <strong>City Controller</strong>. 
                The official vote counts are reported by the Philadelphia City Commissioners’ 
                election results website, and background information about the candidates 
                comes from the Philadelphia Citizen’s 2025 election guide.
            </p>
            <p>
                This page focuses on the final results for all candidates in those two citywide races:
                District Attorney and City Controller.
            </p>
        </section>

        <!-- SECTION 2: District Attorney Results -->
        <section id="da-results" class="section">
            <h2>District Attorney Results</h2>
            <p class="race-summary">
                The 2025 District Attorney race featured two candidates:
                Democrat Larry Krasner and Republican Pat Dugan. According to the
                official city results, Larry Krasner won re-election with a strong majority
                of the vote.<sup>1</sup>
            </p>

            <div class="candidate-grid">
                <!-- Larry Krasner -->
                <article class="candidate-card">
                    <!-- Replace the src value with an actual image URL you download (Krasner headshot) -->
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/Larry_Krasner%2C_Candidate_for_Philadelphia_District_Attorney_%28cropped%29.jpg/450px-Larry_Krasner%2C_Candidate_for_Philadelphia_District_Attorney_%28cropped%29.jpg" 
                         alt="Portrait of District Attorney candidate" class="candidate-photo">

                    <h3 class="candidate-name">
                        <!-- Official campaign website -->
                        <a href="https://krasnerforda.com/" target="_blank" rel="noopener">
                            Larry Krasner
                        </a>
                    </h3>

                    <p class="candidate-party party-dem">
                        Democratic Party
                    </p>

                    <p class="candidate-votes">
                        Votes received: <strong>276,125</strong>
                    </p>
                </article>

                <!-- Pat Dugan -->
                <article class="candidate-card">
                    <!-- Replace with an actual Dugan campaign photo URL if you want -->
                    <img src="https://judgeduganforda.com/wp-content/uploads/2024/12/Headshot.jpg" 
                         alt="Portrait of District Attorney candidate" class="candidate-photo">

                    <h3 class="candidate-name">
                        <a href="https://judgeduganforda.com/" target="_blank" rel="noopener">
                            Pat Dugan
                        </a>
                    </h3>

                    <p class="candidate-party party-rep">
                        Republican Party
                    </p>

                    <p class="candidate-votes">
                        Votes received: <strong>86,305</strong>
                    </p>
                </article>
            </div>
        </section>

        <!-- SECTION 3: City Controller Results -->
        <section id="controller-results" class="section">
            <h2>City Controller Results</h2>
            <p class="race-summary">
                The City Controller race also had two candidates: Democratic incumbent
                Christy Brady and Republican challenger Ari Patrinos. Official results
                show that Christy Brady was re-elected by a wide margin.<sup>1</sup>
            </p>

            <div class="candidate-grid">
                <!-- Christy Brady -->
                <article class="candidate-card">
                    <!-- Replace src with any official Christy Brady photo URL if needed -->
                    <img src="https://controller.phila.gov/wp-content/uploads/2023/11/Christy-Brady-Headshot.jpg" 
                         alt="Portrait of City Controller candidate" class="candidate-photo">

                    <h3 class="candidate-name">
                        <a href="https://bradyforcontroller.com/" target="_blank" rel="noopener">
                            Christy Brady
                        </a>
                    </h3>

                    <p class="candidate-party party-dem">
                        Democratic Party
                    </p>

                    <p class="candidate-votes">
                        Votes received: <strong>294,432</strong>
                    </p>
                </article>

                <!-- Ari Patrinos -->
                <article class="candidate-card">
                    <!-- Replace src with a suitable Ari Patrinos photo URL if needed -->
                    <img src="https://ballotpedia.org/wiki/images/thumb/4/4e/Ari_Patrinos.jpeg/200px-Ari_Patrinos.jpeg" 
                         alt="Portrait of City Controller candidate" class="candidate-photo">

                    <h3 class="candidate-name">
                        <!-- No clear dedicated campaign website found, so we follow the assignment rule -->
                        <span>Ari Patrinos</span>
                    </h3>

                    <p class="candidate-party party-rep">
                        Republican Party
                    </p>

                    <p class="candidate-votes">
                        Votes received: <strong>46,681</strong>
                    </p>

                    <p class="no-website">
                        Campaign website does not exist.  
                    </p>
                </article>
            </div>
        </section>

        <!-- SECTION 4: Sources / About Section -->
        <section id="sources" class="section">
            <h2>About This Page &amp; Sources</h2>
            <p>
                This webpage was created as a class project to practice building a
                multi-section HTML page with semantic elements and internal navigation.
                It summarizes the 2025 Philadelphia election results for District Attorney
                and City Controller.
            </p>
            <ul>
                <li>
                    Official 2025 Philadelphia General Election results for District Attorney
                    and City Controller from the City Commissioners’ website.<sup>1</sup>
                </li>
                <li>
                    Background information on candidates from 
                    <em>The Philadelphia Citizen</em> 2025 PA Election Guide.<sup>2</sup>
                </li>
            </ul>

            <p class="small-print">
                <sup>1</sup> Philadelphia City Commissioners, “District Attorney &amp; City Controller – Philadelphia Election Results.”  
                <br>
                <sup>2</sup> The Philadelphia Citizen, “2025 General Election in Philadelphia, PA” voter guide.
            </p>

            <p>
                <a href="#top">Back to top</a>
            </p>
        </section>
    </main>

    <footer>
        <p>
            &copy; 2025 Philadelphia Election Results Project
        </p>
        <p>
            <!-- Replace YOUR-GITHUB-USERNAME with your real GitHub username -->
            View my projects on 
            <a href="https://github.com/Fannyy2" target="_blank" rel="noopener">
                my GitHub profile
            </a>.
        </p>
    </footer>
</body>
</html>
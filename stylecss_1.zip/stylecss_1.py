/* Basic reset */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

/* Body and overall layout */
body {
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    line-height: 1.6;
    background-color: #f4f4f4;
    color: #222;
}

/* Header */
header {
    background-color: #003366;
    color: #ffffff;
    padding: 1.5rem 1rem 1rem;
    border-bottom: 4px solid #ffcc00;
}

.site-header {
    max-width: 1100px;
    margin: 0 auto 1rem auto;
    text-align: center;
}

.site-header h1 {
    font-size: 2rem;
    margin-bottom: 0.25rem;
}

.tagline {
    font-size: 1rem;
    opacity: 0.9;
}

/* Navigation */
nav {
    background-color: #00244d;
}

.nav-list {
    list-style: none;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    max-width: 1100px;
    margin: 0 auto;
    padding: 0.25rem 0;
}

.nav-list li {
    margin: 0.25rem 0.75rem;
}

.nav-list a {
    color: #ffffff;
    text-decoration: none;
    font-weight: 600;
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
}

.nav-list a:hover,
.nav-list a:focus {
    background-color: #ffcc00;
    color: #000000;
}

/* Sections */
.section {
    max-width: 1100px;
    margin: 1.5rem auto;
    padding: 1rem;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 0 4px rgba(0, 0, 0, 0.08);
}

.section h2 {
    margin-bottom: 0.75rem;
    color: #003366;
}

.section p {
    margin-bottom: 0.75rem;
}

/* Candidate layout */
.candidate-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    margin-top: 1rem;
}

.candidate-card {
    flex: 1 1 240px;
    background-color: #fafafa;
    border-radius: 8px;
    padding: 0.75rem;
    border: 1px solid #e0e0e0;
    text-align: center;
}

.candidate-photo {
    width: 100%;
    max-width: 220px;
    height: auto;
    border-radius: 6px;
    display: block;
    margin: 0 auto 0.75rem auto;
}

.candidate-name {
    margin-bottom: 0.3rem;
    font-size: 1.1rem;
}

.candidate-name a {
    text-decoration: none;
    color: #003366;
}

.candidate-name a:hover,
.candidate-name a:focus {
    text-decoration: underline;
}

/* Party colors based on assignment rules */
.candidate-party {
    margin-bottom: 0.3rem;
    font-weight: bold;
}

/* Democrat = #0066ff */
.party-dem {
    color: #0066ff;
}

/* Republican = #ff0000 */
.party-rep {
    color: #ff0000;
}

/* Other parties would use #ffcc00 (not used in this race) */
.party-other {
    color: #ffcc00;
}

.candidate-votes {
    margin-bottom: 0.3rem;
}

.no-website {
    font-size: 0.9rem;
    color: #555;
}

/* Race summary and sources */
.race-summary {
    background-color: #eef4ff;
    border-left: 4px solid #003366;
    padding: 0.75rem;
    border-radius: 4px;
}

.small-print {
    font-size: 0.85rem;
    color: #555;
}

/* Footer */
footer {
    margin-top: 2rem;
    padding: 1rem;
    text-align: center;
    background-color: #003366;
    color: #ffffff;
}

footer a {
    color: #ffcc00;
    text-decoration: none;
    font-weight: 600;
}

footer a:hover,
footer a:focus {
    text-decoration: underline;
}

/* Make content readable on phones */
@media (max-width: 600px) {
    .site-header h1 {
        font-size: 1.6rem;
    }

    .candidate-grid {
        flex-direction: column;
    }

    .section {
        margin: 1rem;
    }
}